#ifndef TOPOROBO_WIFI_TASKS_H
#define TOPOROBO_WIFI_TASKS_H

void wifi_tasks(void *pv_params);

#endif /* TOPOROBO_WIFI_TASKS_H */
