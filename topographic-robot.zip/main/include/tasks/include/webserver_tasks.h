#ifndef TOPOROBO_WEBSERVER_TASKS_H
#define TOPOROBO_WEBSERVER_TASKS_H

void webserver_tasks(void *pv_params);

#endif /* TOPOROBO_WEBSERVER_TASKS_H */
