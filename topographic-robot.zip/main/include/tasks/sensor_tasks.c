/* Initialization and Reading of Sensors through Tasks */

#include "sensor_tasks.h"
#include "system_tasks.h"
#include <driver/gpio.h>
#include <esp_log.h>

/* Public Functions ***********************************************************/

esp_err_t sensors_comm_init(sensor_data_t *sensor_data)
{
  esp_err_t overall_status = ESP_OK;
  esp_err_t ret = ESP_OK;

  /* Initialize BH1750 */
  ret = bh1750_init(&(sensor_data->bh1750_data), true);
  if (ret != ESP_OK) {
    ESP_LOGE(system_tag, "Failed to initialize BH1750.");
    overall_status = ESP_FAIL;
  }

  /* Initialize DHT22 */
  ret = dht22_init(&(sensor_data->dht22_data), true);
  if (ret != ESP_OK) {
    ESP_LOGE(system_tag, "Failed to initialize DHT22.");
    overall_status = ESP_FAIL;
  }

  /* Initialize MPU6050 */
  ret = mpu6050_init(&(sensor_data->mpu6050_data), true);
  if (ret != ESP_OK) {
    ESP_LOGE(system_tag, "Failed to initialize MPU6050.");
    overall_status = ESP_FAIL;
  }

  /* Initialize QMC5883L */
  ret = qmc5883l_init(&(sensor_data->qmc5883l_data), true);
  if (ret != ESP_OK) {
    ESP_LOGE(system_tag, "Failed to initialize QMC5883L.");
    overall_status = ESP_FAIL;
  }

  /* Initialize GY-NEO6MV2 */
  ret = gy_neo6mv2_init(&(sensor_data->gy_neo6mv2_data), true);
  if (ret != ESP_OK) {
    ESP_LOGE(system_tag, "Failed to initialize GY-NEO6MV2.");
    overall_status = ESP_FAIL;
  }

  if (overall_status == ESP_OK) {
    ESP_LOGI(system_tag, "All sensors initialized successfully.");
  } else {
    ESP_LOGW(system_tag, "Some sensors failed to initialize, but proceeding with available sensors.");
  }
  
  return overall_status;
}

esp_err_t sensor_tasks(sensor_data_t *sensor_data)
{
  esp_err_t overall_status = ESP_OK;
  esp_err_t ret = ESP_OK;

  /* Create task for BH1750 */
  ret = xTaskCreate(bh1750_tasks, "bh1750_task", 2048, &(sensor_data->bh1750_data), 5, NULL);
  if (ret != pdPASS) {
    ESP_LOGE(system_tag, "Failed to create BH1750 task.");
    overall_status = ESP_FAIL;
  }

  /* Create task for DHT22 */
  ret = xTaskCreate(dht22_tasks, "dht22_task", 2048, &(sensor_data->dht22_data), 4, NULL);
  if (ret != pdPASS) {
    ESP_LOGE(system_tag, "Failed to create DHT22 task.");
    overall_status = ESP_FAIL;
  }

  /* Create task for MPU6050 */
  ret = xTaskCreate(mpu6050_tasks, "mpu6050_task", 2048, &(sensor_data->mpu6050_data), 4, NULL);
  if (ret != pdPASS) {
    ESP_LOGE(system_tag, "Failed to create MPU6050 task.");
    overall_status = ESP_FAIL;
  }

  /* Create task for QMC5883L */
  ret = xTaskCreate(qmc5883l_tasks, "qmc5883l_task", 2048, &(sensor_data->qmc5883l_data), 3, NULL);
  if (ret != pdPASS) {
    ESP_LOGE(system_tag, "Failed to create QMC5883L task.");
    overall_status = ESP_FAIL;
  }

  /* Create task for GY-NEO6MV2 */
  ret = xTaskCreate(gy_neo6mv2_tasks, "gy_neo6mv2_task", 2048, &(sensor_data->gy_neo6mv2_data), 3, NULL);
  if (ret != pdPASS) {
    ESP_LOGE(system_tag, "Failed to create GY-NEO6MV2 task.");
    overall_status = ESP_FAIL;
  }

  if (overall_status == ESP_OK) {
    ESP_LOGI(system_tag, "All sensor tasks started successfully.");
  } else {
    ESP_LOGW(system_tag, "Some sensor tasks failed to start, but proceeding with available tasks.");
  }
  
  return overall_status;
}

